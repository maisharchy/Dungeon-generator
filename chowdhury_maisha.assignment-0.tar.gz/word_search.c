#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#define MAX_SIZE 20

typedef struct {
    int dx, dy;
} Direction;

Direction directions[] = {
    {-1, 1},
    {0, 1},
    {1, 1},
    {1, 0}
};

int canPlaceWord(char grid[MAX_SIZE][MAX_SIZE], int n, const char *word, int row, int col, Direction dir) {
    int len = strlen(word);

    for (int i = 0; i < len; i++) {
        int r = row + i * dir.dx;
        int c = col + i * dir.dy;

        if (r < 0 || r >= n || c < 0 || c >= n)
            return 0;

        if (grid[r][c] != '.' && grid[r][c] != word[i])
            return 0;
    }

    return 1;
}

void placeWord(char grid[MAX_SIZE][MAX_SIZE], int n, const char *word, int row, int col, Direction dir) {
    int len = strlen(word);

    for (int i = 0; i < len; i++) {
        int r = row + i * dir.dx;
        int c = col + i * dir.dy;

        grid[r][c] = word[i];
    }
}

void fillEmptySpaces(char grid[MAX_SIZE][MAX_SIZE], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (grid[i][j] == '.') {
                grid[i][j] = 'a' + rand() % 26;
            }
        }
    }
}

void printGrid(char grid[MAX_SIZE][MAX_SIZE], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%c ", grid[i][j]);
        }
        printf("\n");
    }
}


int attemptPlaceWord(char grid[MAX_SIZE][MAX_SIZE], int n, const char *word) {
    int len = strlen(word);

    if (len > n) {
        printf("Word too large to fit in the grid\n");
        return 0;
    }

    for (int row = 0; row < n; row++) {
        for (int col = 0; col < n; col++) {
            for (int d = 0; d < 4; d++) {
                Direction dir = directions[d];

                if (canPlaceWord(grid, n, word, row, col, dir)) {
                    placeWord(grid, n, word, row, col, dir);
                    return 1;
                }
            }
        }
    }

    return 0;
}


int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s <grid_size> <word1> <word2> ...\n", argv[0]);
        return 1;
    }

    int n = atoi(argv[1]);
    if (n < 1 || n > MAX_SIZE) {
        printf("Grid size must be between 1 and %d.\n", MAX_SIZE);
        return 1;
    }

    char grid[MAX_SIZE][MAX_SIZE];
    memset(grid, '.', sizeof(grid));

    srand(time(NULL));

    for (int i = 2; i < argc; i++) {
        const char *word = argv[i];
        if (!attemptPlaceWord(grid, n, word)) {
            printf("Failed to place the word: %s\n", word);
            return 1;
        }
    }

    fillEmptySpaces(grid, n);
    printGrid(grid, n);

    printf("\nWord list:\n");
    for (int i = 2; i < argc; i++) {
        printf("%s\n", argv[i]);
    }

    return 0;
}
