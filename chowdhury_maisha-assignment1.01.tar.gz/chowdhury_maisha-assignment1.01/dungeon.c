#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define WIDTH 80
#define HEIGHT 21
#define MIN_ROOMS 6
#define MAX_ROOMS 10
#define MIN_ROOM_WIDTH 4
#define MIN_ROOM_HEIGHT 3
#define ROCK ' '
#define ROOM '.'
#define CORRIDOR '#'
#define UP_STAIR '<'
#define DOWN_STAIR '>'

typedef struct {
    int x, y, width, height;
} Room;

char dungeon[HEIGHT][WIDTH];
Room rooms[MAX_ROOMS];
int room_count = 0;

void init_dungeon() {
    for (int y = 0; y < HEIGHT; y++) {
        for (int x = 0; x < WIDTH; x++) {
            dungeon[y][x] = ROCK;
        }
    }
}

int is_valid_room(int x, int y, int w, int h) {
    if (x + w >= WIDTH - 1 || y + h >= HEIGHT - 1) return 0;
    for (int i = y - 1; i <= y + h; i++) {
        for (int j = x - 1; j <= x + w; j++) {
            if (i >= 0 && j >= 0 && i < HEIGHT && j < WIDTH && dungeon[i][j] != ROCK) {
                return 0;
            }
        }
    }
    return 1;
}

void place_rooms() {
    while (room_count < MIN_ROOMS) {
        int w = MIN_ROOM_WIDTH + rand() % 6;
        int h = MIN_ROOM_HEIGHT + rand() % 4;
        int x = 1 + rand() % (WIDTH - w - 2);
        int y = 1 + rand() % (HEIGHT - h - 2);
        
        if (is_valid_room(x, y, w, h)) {
            for (int i = y; i < y + h; i++) {
                for (int j = x; j < x + w; j++) {
                    dungeon[i][j] = ROOM;
                }
            }
            rooms[room_count++] = (Room){x, y, w, h};
        }
    }
}

void connect_rooms() {
    for (int i = 1; i < room_count; i++) {
        Room a = rooms[i - 1], b = rooms[i];
        int x1 = a.x + a.width / 2, y1 = a.y + a.height / 2;
        int x2 = b.x + b.width / 2, y2 = b.y + b.height / 2;
        
        while (x1 != x2) {
            if (dungeon[y1][x1] == ROCK) {
                dungeon[y1][x1] = CORRIDOR;
            }
            x1 += (x2 > x1) ? 1 : -1;
        }

        while (y1 != y2) {
            if (dungeon[y1][x1] == ROCK) {
                dungeon[y1][x1] = CORRIDOR;
            }
            y1 += (y2 > y1) ? 1 : -1;
        }
    }
}


void place_staircases() {
    int up_index = rand() % room_count;
    int down_index;
    do {
        down_index = rand() % room_count;
    } while (down_index == up_index);
    
    Room up_room = rooms[up_index];
    Room down_room = rooms[down_index];
    
    dungeon[up_room.y + up_room.height / 2][up_room.x + up_room.width / 2] = UP_STAIR;
    dungeon[down_room.y + down_room.height / 2][down_room.x + down_room.width / 2] = DOWN_STAIR;
}

void print_dungeon() {
    for (int y = 0; y < HEIGHT; y++) {
        for (int x = 0; x < WIDTH; x++) {
            printf("%c", dungeon[y][x]);
        }
        printf("\n");
    }
}

int main() {
    srand(time(NULL));
    init_dungeon();
    place_rooms();
    connect_rooms();
    place_staircases();
    print_dungeon();
    return 0;
}
